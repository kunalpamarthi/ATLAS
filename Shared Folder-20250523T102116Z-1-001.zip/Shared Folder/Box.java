package OOP;

public class Box {
    double l = -1;
    double w = -1;
    double h = -1;
}
